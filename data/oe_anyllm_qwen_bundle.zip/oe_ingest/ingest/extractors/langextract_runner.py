from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from any_llm import completion

from oe_ingest.schema.models import OldEnglishText, TextMetadata

@dataclass(frozen=True)
class AnyLLMConfig:
    provider: str = "ollama"
    model_id: str = "qwen2.5:14b-instruct"
    temperature: float = 0.0
    max_tokens: int = 4096
    timeout_s: int = 120

def _load_prompt(prompt_path: Path) -> str:
    return prompt_path.read_text(encoding="utf-8").strip()

def _messages(prompt: str, text: str) -> list[dict[str,str]]:
    return [
        {"role":"system","content":prompt},
        {"role":"user","content":"INPUT TEXT (Old English only):\n\n"+text},
    ]

def _extract_json_object(raw: str) -> dict[str, Any]:
    s = raw.strip()
    if s.startswith("```"):
        s = s.split("\n", 1)[1] if "\n" in s else s
        s = s.rsplit("```", 1)[0].strip()
    try:
        obj = json.loads(s)
        if isinstance(obj, dict):
            return obj
    except Exception:
        pass
    start = s.find("{")
    if start < 0:
        raise ValueError("No JSON object found in output")
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(s)):
        ch = s[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":  # escape
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return json.loads(s[start:i+1])
    raise ValueError("Could not extract JSON object from output")

def run_anyllm_to_canonical(
    *,
    text: str,
    metadata: TextMetadata,
    prompt_path: Path,
    prompt_preamble: str | None = None,
    config: AnyLLMConfig | None = None,
) -> OldEnglishText:
    cfg = config or AnyLLMConfig()
    prompt = _load_prompt(prompt_path)
    if prompt_preamble:
        prompt = prompt_preamble.rstrip() + "\n\n" + prompt
    raw = completion(
        model=cfg.model_id,
        messages=_messages(prompt, text),
        provider=cfg.provider,
        temperature=cfg.temperature,
        max_tokens=cfg.max_tokens,
        timeout=cfg.timeout_s,
    )
    if not isinstance(raw, str):
        raw = str(raw)
    obj = _extract_json_object(raw)
    if "metadata" not in obj:
        obj["metadata"] = metadata.model_dump(mode="json", exclude_none=True)
    return OldEnglishText.model_validate(obj)
