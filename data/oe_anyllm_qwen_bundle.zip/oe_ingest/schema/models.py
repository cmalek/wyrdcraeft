from __future__ import annotations
from typing import Optional
from pydantic import BaseModel

class TextMetadata(BaseModel):
    title: str
    source: Optional[str] = None
    author: Optional[str] = None
    year: Optional[str] = None
    editor: Optional[str] = None
    license: Optional[str] = None
    language: str = "ang"

class Sentence(BaseModel):
    text: str
    number: Optional[str|int] = None
    source_page: Optional[int|str] = None
    confidence: Optional[float] = None

class Paragraph(BaseModel):
    speaker: Optional[str] = None
    sentences: list[Sentence]
    source_page: Optional[int|str] = None
    confidence: Optional[float] = None

class Line(BaseModel):
    text: str
    number: Optional[int|str] = None
    speaker: Optional[str] = None
    source_page: Optional[int|str] = None
    confidence: Optional[float] = None

class Section(BaseModel):
    title: Optional[str] = None
    number: Optional[str|int] = None
    sections: Optional[list["Section"]] = None
    paragraphs: Optional[list[Paragraph]] = None
    lines: Optional[list[Line]] = None
    source_page: Optional[int|str] = None
    confidence: Optional[float] = None

Section.model_rebuild()

class OldEnglishText(BaseModel):
    schema_version: str = "1.0"
    metadata: TextMetadata
    content: Section
